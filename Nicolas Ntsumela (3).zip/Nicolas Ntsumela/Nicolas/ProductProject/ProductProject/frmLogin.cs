﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace ProductProject
{
    public partial class frmLogin : Form
    {
        OleDbConnection connection = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\Nicolas\Documents\Visual Studio 2013\Projects\ProductProject\ProductProject\Products.accdb");

        public frmLogin()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            connection.Open();
                string sql = @"select * 
                               from tblUser 
                               where userName ='" + txtUserName.Text +
                               "'and userpassword ='" + txtPassword.Text + "'";
                OleDbCommand comm = new OleDbCommand(sql, connection);

                OleDbDataReader reader = comm.ExecuteReader();

                int count = 0;

                while(reader.Read())
                {
                    count++;
                }

                connection.Close();
                if(count == 1)
                {
                    this.Hide();
                    frmMain MyMain = new frmMain();
                    MyMain.Show();
                }

                else
                {
                    MessageBox.Show("No Match", "Not Found", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void frmLogin_Load(object sender, EventArgs e)
        {

        }
    }
}
